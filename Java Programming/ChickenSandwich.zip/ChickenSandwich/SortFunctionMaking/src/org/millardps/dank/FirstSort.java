package org.millardps.dank;
 
import java.util.ArrayList;

public class FirstSort {
	
	public FirstSort(ArrayList<String> x){
		
	}
}
