package org.millardps.dank;

import java.util.ArrayList;

public class Runna {

	public static void main(String[] args) {
		ArrayList <String> meta = new ArrayList<String>();
		meta.add("zoo");
		//meta.add("dog");
		meta.add("cat");
		meta.add("rider");
		meta.add("train");
		meta.add("kat");
		ThirdSort billy = new ThirdSort(meta);

	}

}
