package org.millardps.dank;

import java.util.ArrayList;

public class ThirdSort {
	String c;
	public ThirdSort(ArrayList<String> x){
		for(int i = 0; i < x.size(); i++){
			for(int z = i; z < x.size(); z++){
				c = x.get(i);
				if(c.compareTo(x.get(z)) > 1){
					String temp = x.get(z);
					x.remove(z);
					x.add(i, temp);
					System.out.println(x);
				}
			}
		}
	}
}
