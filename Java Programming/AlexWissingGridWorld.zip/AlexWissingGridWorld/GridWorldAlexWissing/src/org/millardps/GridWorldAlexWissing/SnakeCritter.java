package org.millardps.GridWorldAlexWissing;

import info.gridworld.actor.Critter;

public class SnakeCritter extends Critter {
	
}
