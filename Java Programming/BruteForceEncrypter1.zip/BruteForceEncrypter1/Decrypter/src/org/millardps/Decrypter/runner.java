package org.millardps.Decrypter;

public class runner {

	public static void main(String[] args) {
		decrypter billy = new decrypter();
		
	}

}
