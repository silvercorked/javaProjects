package org.millardps.miniProjects;

public class Palindrome {

	public static void main(String[] args) {
		madLibGen billy = new madLibGen();

	}

}
